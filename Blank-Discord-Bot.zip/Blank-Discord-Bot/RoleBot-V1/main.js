const { channel } = require('diagnostics_channel');
const { Client, Intents } = require('discord.js');
const Discord = require('discord.js');

const client = new Discord.Client({ intents: ["GUILDS", "GUILD_MESSAGES", 'DIRECT_MESSAGES', 'GUILD_MEMBERS', 'GUILD_MESSAGE_REACTIONS', 'DIRECT_MESSAGE_REACTIONS']}, {partials: ["MESSAGE", "CHANNEL", "REACTION"] })
const prefix = '!';

var fs = require('fs');

client.once('ready', () => {
    console.log('Role Bot is Online!');
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;
    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();


    if(command === 'role'){
        client.commands.get('test').execute(message, args, Discord, client);
    }


});

client.login('');
